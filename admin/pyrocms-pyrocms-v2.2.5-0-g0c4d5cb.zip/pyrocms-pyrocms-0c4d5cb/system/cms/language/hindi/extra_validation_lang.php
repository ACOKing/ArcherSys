<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "%s सिर्फ अक्षरांकीय वर्ण, रेखांकित वर्ण, बिंदु और '-' का इस्तेमाल कर सकते हैं।";
$lang['decimal']				= "%s आप सिर्फ दशांश आंकड़ो का इस्तेमाल कर सकते हैं।";
$lang['csrf_bad_token']			= "सी.आर.ऍफ़. गलत हैं।";

/* End of file extra_validation_lang.php */