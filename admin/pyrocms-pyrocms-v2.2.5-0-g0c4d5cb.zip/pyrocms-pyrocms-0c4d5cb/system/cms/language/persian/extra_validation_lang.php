<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "فیلد  می تواند حاوی کلمات انگلیسی کوچک، آندرلاین، نقطه و یا خط فاصله باشد";
$lang['decimal']				= 'فیلد %s می تواند حاوی اعداد باشد';
$lang['csrf_bad_token']			= "CSRF Token غیر قابل قبول";

/* End of file extra_validation_lang.php */