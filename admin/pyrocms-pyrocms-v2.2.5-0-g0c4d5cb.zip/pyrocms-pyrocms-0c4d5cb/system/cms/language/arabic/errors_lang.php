<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'الصفحة مفقودة';
$lang['error_404_message'] = 'لم نتمكن من العثور على الصفحة التي تبحث عنها، رجاء اضغط <a href="%s">هنا</a> للعودة إلى الصفحة الرئيسية.';

// Database
$lang['error_invalid_db_group'] = 'تحاول قاعدة البيانات استخدام مجموعة التهيئة "%s" الغير صالحة.';

/* End of file errors_lang.php */