<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Введение';
$lang['step1']	=	'Шаг #1';
$lang['step2']	=	'Шаг #2';
$lang['step3']	=	'Шаг #3';
$lang['step4']	=	'Шаг #4';
$lang['final']	=	'Завершение';

$lang['installer.passwords_match']        = "Пароли совпадают.";
$lang['installer.passwords_dont_match']    = "Пароли не совпадают.";