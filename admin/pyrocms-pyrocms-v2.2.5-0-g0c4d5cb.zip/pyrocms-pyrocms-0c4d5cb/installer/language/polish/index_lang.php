<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'Witamy';
$lang['thankyou']	= 	'Dziękujemy za wybranie PyroCMS!';
$lang['text']		=	'Instalacja PyroCMS jest bardzo prosta, wystarczy śledzić komunikaty na ekranie. Gdy nie będziesz czegoś pewien, nie przejmuj się, instalator wytłumaczy co należy zrobić.';
$lang['step1'] 		= 'Krok 1';
$lang['link']		= 'Przejdź do pierwszego kroku';
