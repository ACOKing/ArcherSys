<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Tillykke';
$lang['intro_text']			= 'PyroCMS er nu installeret og klar til at blive brugt! Log venligst ind i kontrolpanelet med følgende oplysninger.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Kodeord';
$lang['show_password']		= 'Show Password?'; #translate
$lang['outro_text']			= 'Afslutningsvis, <strong>slet installer mappen fra din server</strong> dit website kan blive hacket hvis du lader den blive.';

$lang['go_website']			= 'Gå til Website';
$lang['go_control_panel']	= 'Gå til Kontrolpanel';