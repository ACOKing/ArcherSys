<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'Intro';
$lang['step1']	=	'Step #1';
$lang['step2']	=	'Step #2';
$lang['step3']	=	'Step #3';
$lang['step4']	=	'Step #4';
$lang['final']	=	'Final Step';

$lang['installer.passwords_match']		= 'Passwords match.';
$lang['installer.passwords_dont_match']	= 'Passwords do not match.';