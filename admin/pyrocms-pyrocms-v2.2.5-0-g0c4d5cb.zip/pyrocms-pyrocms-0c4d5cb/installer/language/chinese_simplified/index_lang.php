<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'歡迎';
$lang['thankyou']	= 	'謝謝您選擇 PyroCMS！';
$lang['text']		=	'安裝 PyroCMS 很簡單，您只要按照畫面中的步骤與指示進行即可。如果您在安裝的過程中遇到問題，請不用擔心，安裝程式將會提示您該如何做。';
$lang['step1'] 		= 	'步骤一';
$lang['link']		= 	'開始進行第一個步骤';
