<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'簡介';
$lang['step1']	=	'步骤一';
$lang['step2']	=	'步骤二';
$lang['step3']	=	'步骤三';
$lang['step4']	=	'步骤四';
$lang['final']	=	'最后一步';

$lang['installer.passwords_match']		= "密码符合";
$lang['installer.passwords_dont_match']	= "密码不符合";