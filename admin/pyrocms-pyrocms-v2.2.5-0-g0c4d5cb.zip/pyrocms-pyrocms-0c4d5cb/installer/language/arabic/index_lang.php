<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'أهلاً بك';
$lang['thankyou']	= 	'نشكرك على اختيارك PyroCMS!';
$lang['text']		=	'تثبيت PyroCMS سهل للغاية، فقط اتبع التعليمات على الشاشة. إن واجهت أية مشاكل في عملية التثبيت فلا تقلق حيث أن برنامج التثبيت سيرشدك إلى ما يجب عمله.';
$lang['step1'] 		= 'الخطوة الأولى';
$lang['link']		= 'تقدم إلى الخطوة الأولى';