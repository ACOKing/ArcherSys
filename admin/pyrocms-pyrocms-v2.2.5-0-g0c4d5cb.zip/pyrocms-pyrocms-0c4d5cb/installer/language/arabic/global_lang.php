<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['intro']	=	'المقدمة';
$lang['step1']	=	'الخطوة الأولى';
$lang['step2']	=	'الخطوة الثانية';
$lang['step3']	=	'الخطوة الثالثة';
$lang['step4']	=	'الخطوة الرابعة';
$lang['final']	=	'الخطوة الأخيرة';

$lang['installer.passwords_match']		= "كلمتا السرّ متطابقتان.";
$lang['installer.passwords_dont_match']	= "كلمتا السرّ غير متطابقتين.";