<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']	=	'Félicitations';
$lang['intro_text']	=	'PyroCMS est maintenant installé et prêt à être utilisé ! Connectez-vous au panel d\'administration avec les détails suivants.';
$lang['email']		=	'E-mail';
$lang['password']	=	'Mot de passe';
$lang['show_password']		= 'Voir le Mot de passe';
$lang['outro_text']	=	'Pour finir, <strong>effacer le répertoire /installer de votre serveur</strong> afin d\'éviter qu\'il soit utilisé pour pirater votre site.';

$lang['go_website']			= 'Allez au site';
$lang['go_control_panel']	= 'Allez au panel d\'administration';