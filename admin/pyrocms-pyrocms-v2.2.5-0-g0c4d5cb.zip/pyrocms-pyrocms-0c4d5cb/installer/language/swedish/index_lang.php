<?php defined('BASEPATH') or exit('No direct script access allowed');

 /**
 * Swedish translation.
 *
 * @author		marcus@incore.se
 * @package		PyroCMS  
 * @link		http://pyrocms.com
 * @date		2012-10-22
 * @version		1.1.0
 */

$lang['header'] = 'Välkommen';
$lang['thankyou'] = 'Tack för att du väljer PyroCMS!';
$lang['text'] = 'Att installera PyroCMS är väldigt enkelt, följ bara instruktionerna i denna installtionsguide. Får du problem under installationen kommer installationsprogrammet att ge dig förslag på nödvändiga åtgärder.';
$lang['step1'] = 'Steg 1';
$lang['link'] = 'Fortsätt';