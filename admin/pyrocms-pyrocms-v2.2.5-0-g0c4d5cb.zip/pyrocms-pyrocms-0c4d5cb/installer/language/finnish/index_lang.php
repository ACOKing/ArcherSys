<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['header']		=	'Tervetuloa';
$lang['thankyou']	= 	'Kiitos, että valitsit PyroCMS:n!';
$lang['text']		=	'PyroCMS asetaminen on erittäin helppoa. Seuraa vaiheita ja ohjeita ruudulla. Jos sinulla on jotain ongelmia järjestelmän asentamisessa, niin sinua ohjeistetaan niiden kanssa.';
$lang['step1'] 		= 'Vaihe 1';
$lang['link']		= 'Aloita ensimmäinen vaihe';