<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']			= 'Συγχαρητήρια';
$lang['intro_text']			= 'Το PyroCMS είναι πλέον εγκατεστημένο και έτοιμο! Παρακαλούμε συνδεθείτε στον πίνακα διαχείρισης με τα παρακάτω στοιχεία.';
$lang['email']				= 'E-mail';
$lang['password']			= 'Συνθηματικό';
$lang['show_password']		= 'Εμφάνιση συνθηματικού;';
$lang['outro_text']			= 'Εν τέλει, <strong>διαγράψτε τον φάκελο installer από τον διακομιστή σας</strong> αφού αν το αφήσετε εκεί μπορεί να χρησιμοποιηθεί για να κακοποιηθεί ο ιστότοπός σας.';

$lang['go_website']			= 'Μετάβαση στον Ιστότοπο';
$lang['go_control_panel']	= 'Μετάβαση στον Πίνακα Διαχείρισης';