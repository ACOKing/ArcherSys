<?php defined('BASEPATH') or exit('No direct script access allowed');

// labels
$lang['congrats']	=	'Gefeliciteerd!';
$lang['intro_text']	=	'PyroCMS is geïnstalleerd en klaar voor gebruik! U kunt inloggen in het admininstratiepaneel met de volgende gegevens.';
$lang['email']		=	'Email';
$lang['password']	=	'Wachtwoord';
$lang['show_password']	= 'Wachtwoord weergeven?';
$lang['outro_text']	=	'Tot slot dient u de <b>installer van de server te verwijderen</b>. Anders kan een kwaadwillende gebruiker uw systeem overnemen.';

$lang['go_website']			= 'Ga naar de Website';
$lang['go_control_panel']	= 'Ga naar het Controlepaneel';